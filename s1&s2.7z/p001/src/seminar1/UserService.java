package seminar1;

import java.util.HashSet;
import java.util.Set;

public class UserService {
    private Set<User> users;

    public UserService() {
        this.users = new HashSet<>();
    }

    public void addUser(User user) {
        this.users.add(user);
    }

    public void removeUser(int id) {
        this.users.removeIf(user -> user.getId() == id);
    }

    public Set<User> getAllUsers() {
        return this.users;
    }
//  metode care incalca YAGNI, nu sunt apelate in Main.
//    public void updateUser(seminar1.User user){
//        if(!this.users.contains(user)) {
//            throw new RuntimeException("Not Found");
//        }
//
//        this.users.add(user);
//    }
//
//    public seminar1.User findUserByName(String name){
//        return this.users.stream()
//                .filter(user -> user.getName().equals(name))
//                .findFirst()
//                .orElseThrow(() -> new RuntimeException("Not found"));
//    }
}
