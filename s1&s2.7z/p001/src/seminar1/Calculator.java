package seminar1;

public class Calculator {
    public double add(double a, double b) {
// incalca KISS
        //        if(a<0){
//            throw new ArithmeticException("A is negative");
//        }else if (b<0){
//            throw new ArithmeticException("B is negative");
//        }
        return a + b;
    }

    public double substract(double a, double b) {
        //incalca KISS
//        if(a<b){
//            throw new ArithmeticException("A too low");
//        }
        return a - b;
    }

    public double multiply(double a, double b) {
// incalca KISS
//        if(a%2==0 || b%2==0){
//            System.out.println("Par");
//        }else{
//            System.out.println("Impar");
//        }
        return a * b;
    }

    public double divide(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("B = 0");
        }
        return a / b;
    }
}
