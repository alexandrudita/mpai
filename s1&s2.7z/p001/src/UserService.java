import java.util.ArrayList;
import java.util.List;

public class UserService {
    private final List<User> listaUtilizatori = new ArrayList<>();

    public void addUser(User user) {
        if (listaUtilizatori.stream().anyMatch(u -> u.getId() == user.getId())) {
            throw new RuntimeException("User with that id already exists");
        }
        listaUtilizatori.add(user);
    }

    public void removeUser(int id) {
        boolean userDeleted = listaUtilizatori.removeIf(user -> user.getId() == id);
        if (!userDeleted) {
            throw new RuntimeException("User was not deleted");
        }
    }

    public List<User> getAllUsers() {
        return listaUtilizatori;
    }
}
