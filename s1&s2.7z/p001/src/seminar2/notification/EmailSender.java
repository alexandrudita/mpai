package seminar2.notification;

public interface EmailSender {

    void sendAttachment(String attachment);
}
