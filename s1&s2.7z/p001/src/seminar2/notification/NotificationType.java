package seminar2.notification;

public enum NotificationType {

    EMAIL,SMS
}
