package seminar2.notification;

import seminar2.User;

public class EmailNotification implements Notification, EmailSender {

    private String email;

    public EmailNotification(String email) {
        this.email = email;
    }

    @Override
    public boolean check(NotificationType type) {
        return NotificationType.EMAIL.equals(type);
    }

    @Override
    public void sendNotification(User user, String message) {
        System.out.println(message +" sent successfully to email: "+ user.getEmail());
    }

    @Override
    public void sendAttachment(String attachment) {
        System.out.println("Attachment " + attachment +" sent successfully to email: "+ email);
    }
}
