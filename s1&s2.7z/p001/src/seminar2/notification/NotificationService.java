package seminar2.notification;

import seminar2.User;

import java.util.Arrays;
import java.util.List;

public class NotificationService {

    private List<Notification> notifications;



    public NotificationService(List<Notification> notifications) {
        this.notifications = notifications;
    }

    public void sendNotifications(String message, User user, NotificationType... types){

        Arrays.stream(types).forEach(type -> sendNotification(message,user,type));
    }

    private void sendNotification(String message, User user, NotificationType type){
        notifications
                .stream()
                .filter(notification -> notification.check(type))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No notification found"))
                .sendNotification(user,message);
    }
}
