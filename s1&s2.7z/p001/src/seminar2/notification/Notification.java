package seminar2.notification;

import seminar2.User;

public interface Notification {

    boolean check(NotificationType type);

    void sendNotification(User user, String message);
}
