package seminar2.notification;

import seminar2.User;

public class SMSNotification implements Notification {

    private String phoneNumber;

    public SMSNotification(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Override
    public boolean check(NotificationType type) {
        return NotificationType.SMS.equals(type);
    }

    @Override
    public void sendNotification(User user,String message) {
        System.out.println(message +" sent successfully to phone number: "+ user.getPhoneNumber());
    }
}
