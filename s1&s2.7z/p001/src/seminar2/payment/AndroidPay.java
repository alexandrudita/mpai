package seminar2.payment;

import seminar2.User;

public class AndroidPay implements PaymentMethod {

    private double balance;

    public AndroidPay(double balance) {
        this.balance = balance;
    }

    public boolean validateBalance(double amount){
        return balance > amount;
    }


    @Override
    public void pay(User user, double amount) {
        System.out.println("User: "+ user + " pays" + amount + " dollars - Android");

    }
}
