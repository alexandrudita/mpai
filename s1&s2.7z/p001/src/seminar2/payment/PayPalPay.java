package seminar2.payment;

import seminar2.User;

public class PayPalPay implements PaymentMethod{

    private String password;

    public PayPalPay( String password) {
        this.password = password;
    }

    public boolean validateCredentials(User user){
        System.out.println("Check password: "+ password + " for user: "+ user.getEmail());
        return true;
    }

    @Override
    public void pay(User user, double amount) {
        System.out.println("User: "+ user + " pays" + amount + " dollars - PayPal");
    }
}
