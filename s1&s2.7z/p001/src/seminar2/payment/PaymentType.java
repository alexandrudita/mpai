package seminar2.payment;

public enum PaymentType {

    ANDROID, APPLE, PAYPAL
}
