package seminar2.payment;

import seminar2.User;

public class ApplePay implements  PaymentMethod {

    private String faceID;

    public ApplePay(String faceID) {
        this.faceID = faceID;
    }

    public boolean validateFaceID(String faceID){
        return this.faceID.equals(faceID);
    }


    @Override
    public void pay(User user, double amount) {
        System.out.println("User: "+ user + " pays" + amount + " dollars - Apple");
    }
}
