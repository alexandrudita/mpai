package seminar2.payment;


import seminar2.User;

import java.util.Map;

public class PaymentProcessor {

    Map<PaymentType, PaymentMethod> paymentMethods;

    public PaymentProcessor(Map<PaymentType, PaymentMethod> paymentMethods) {
        this.paymentMethods = paymentMethods;
    }

    public void pay(User user, double amount, PaymentType type){
        if(!paymentMethods.containsKey(type)){
            throw new RuntimeException("Not supported");
        }
        paymentMethods.get(type).pay(user,amount);
    }
}
