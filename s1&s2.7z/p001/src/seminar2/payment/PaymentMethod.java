package seminar2.payment;

import seminar2.User;

public interface PaymentMethod {

    void pay(User user, double amount );
}
