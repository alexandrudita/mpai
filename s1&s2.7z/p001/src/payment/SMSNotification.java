package payment;

public class SMSNotification implements Notification{
    @Override
    public void sendNotification(String message) {
        System.out.println("SMS notification is sent...");
    }

    @Override
    public boolean check(NotificationType notificationType) {
        return notificationType.equals(NotificationType.SMS);
    }
}
