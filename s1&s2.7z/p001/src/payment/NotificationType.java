package payment;

public enum NotificationType {
    SMS, EMAIL, PUSH
}
