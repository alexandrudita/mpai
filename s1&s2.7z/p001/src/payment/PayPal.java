package payment;

public class PayPal {
}
