package payment;

public class ApplePay extends Processor{
    public void validateTransactionFaceId() {

    }

    @Override
    public void pay() {
        System.out.println("S-a platit...");
    }
}
