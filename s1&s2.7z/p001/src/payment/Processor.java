package payment;

public abstract class Processor {
    public abstract void pay();
}
