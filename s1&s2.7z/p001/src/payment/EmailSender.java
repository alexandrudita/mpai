package payment;

public interface EmailSender {
    void sendAttachement(String attachement);
}
