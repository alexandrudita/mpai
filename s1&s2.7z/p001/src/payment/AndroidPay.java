package payment;

public class AndroidPay extends Processor {
    public void checkBalanceBeforePayment() {

    }

    @Override
    public void pay() {
        System.out.println("S-a platit...");
    }
}
