package payment;

public class EmailNotification implements Notification, EmailSender{
    @Override
    public void sendNotification(String message) {
        System.out.println("Email notification is sent...");
    }

    @Override
    public boolean check(NotificationType notificationType) {
        return notificationType.equals(NotificationType.EMAIL);
    }

    @Override
    public void sendAttachement(String attachement) {
        System.out.println("S-a trimis mesajul...");
    }
}
