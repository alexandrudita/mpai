package payment;

import java.util.List;

public class NotificationService {
    private final List<Notification> notificationList;

    public NotificationService(List<Notification> notificationList) {
        this.notificationList = notificationList;
    }

    public void send(NotificationType notificationType, String message) {
        notificationList.stream()
                .filter(n -> n.check(notificationType))
                .findAny()
                .orElseThrow(() -> new RuntimeException("Runtime exception"))
                .sendNotification(message);
    }
}
