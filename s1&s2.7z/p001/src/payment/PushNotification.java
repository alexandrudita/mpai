package payment;

public class PushNotification implements Notification{
    @Override
    public void sendNotification(String message) {
        System.out.println("Push notification sent...");
    }

    @Override
    public boolean check(NotificationType notificationType) {
        return notificationType.equals(NotificationType.PUSH);
    }
}
