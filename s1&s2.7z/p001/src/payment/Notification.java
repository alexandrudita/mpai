package payment;

public interface Notification {
    void sendNotification(String message);
    boolean check(NotificationType notificationType);
}
