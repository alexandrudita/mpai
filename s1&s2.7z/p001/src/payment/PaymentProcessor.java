package payment;

import java.util.HashMap;

public class PaymentProcessor {
    private final HashMap<String, Processor> processors;

    public PaymentProcessor(HashMap<String, Processor> processors) {
        this.processors = processors;
    }

    public void sendToProcessor(String processorType){
        if(!processors.containsKey(processorType)){
            throw new RuntimeException("Nu exista...");
        }
        processors.get(processorType).pay();
    }
}
