import seminar1.Calculator;
import seminar1.User;
import seminar1.UserService;
import seminar2.notification.EmailNotification;
import seminar2.notification.NotificationService;
import seminar2.notification.NotificationType;
import seminar2.notification.SMSNotification;
import seminar2.payment.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        exercitiul1();
        exercitiul2();
        NotificationService service = new NotificationService(
                List.of(new SMSNotification("0701213342")
                , new EmailNotification("abc@email.com")));
        seminar2.User user = new seminar2.User(1,"example@email.com","0734233424");
        service.sendNotifications("Salut",user, NotificationType.SMS, NotificationType.EMAIL);
        service.sendNotifications("Mesaj nou",user, NotificationType.SMS);
        service.sendNotifications("Email nou",user, NotificationType.EMAIL);

        Map<PaymentType, PaymentMethod> methods
                = Map.of(
                        PaymentType.ANDROID,new AndroidPay(300),
                PaymentType.APPLE,new ApplePay("2b-3dfeewq"),
                PaymentType.PAYPAL,new PayPalPay("password")
                );
        PaymentProcessor processor = new PaymentProcessor(methods);
        processor.pay(user,100,PaymentType.APPLE);

    }


    private static void exercitiul1() {
        UserService userService = new UserService();
        User andrei = new User(1, "Andrei");
        User mihai = new User(2, "Mihai");
        User vasile = new User(3, "Vasile");

        userService.addUser(andrei);
        userService.addUser(mihai);
        userService.addUser(vasile);

        Set<User> users = userService.getAllUsers();
        System.out.println(users);
        System.out.println("--------");
        userService.removeUser(andrei.getId());
        users = userService.getAllUsers();
        System.out.println(users);
    }

    private static void exercitiul2() {
        Calculator calculator = new Calculator();
        double addResult = calculator.add(10, 20);
        System.out.println("Add result: " + addResult);
        double substractResult = calculator.substract(10, 5);
        System.out.println("Substract result: " + substractResult);
        double multiplyResult = calculator.multiply(2, 3);
        System.out.println("Multiply result: " + multiplyResult);
        double divideResult = calculator.divide(10, 5);
        System.out.println("Divide result: " + divideResult);
    }
}