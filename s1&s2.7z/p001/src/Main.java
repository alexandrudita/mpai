//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
         User user1 = new User(1,"Alex");
         UserService userService1 = new UserService();

         userService1.addUser(user1);
         userService1.getAllUsers().forEach(System.out::println);

         userService1.removeUser(1);
         userService1.getAllUsers().forEach(System.out::println);
    }
}